from flask import render_template,redirect,session,request, flash
from flask_app import app
from flask_app.models.sandwich import Sandwich
from flask_app.models.user import User

@app.route('/cart')
def my_cart_page():
    sandwiches = Sandwich.get_by_in_cart()
    return render_template('cart.html',sandwiches=sandwiches)

@app.route('/sandwiches')
def previous_orders_page():
    sandwiches = Sandwich.get_all()
    return render_template("sandwiches.html",sandwiches=sandwiches)

@app.route('/remove_from_cart/<sandwich_id>')
def remove_one_from_cart(sandwich_id):
    Sandwich.remove_from_cart(sandwich_id)
    return redirect('/cart')

@app.route('/add_to_cart/<sandwich_id>')
def add_to_cart(sandwich_id):
    Sandwich.add_to_cart(sandwich_id)
    return redirect('/sandwiches')

@app.route('/purchase')
def purchase_cart():
    Sandwich.purchase_from_cart()
    return redirect('/cart')

@app.route('/delete/<sandwich_id>')
def delete_sandwich(sandwich_id):
    Sandwich.delete(sandwich_id)
    return redirect('/sandwiches')

@app.route('/creating_sandwich', methods=['POST'])
def creating_sandwich():
    Sandwich.save(request.form)
    return redirect('/order')
