from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app.models.user import User


class Sandwich:
    DB = 'sandwiches'
    def __init__(self,data):
        self.id = data["id"]
        self.is_in_cart = data["is_in_cart"]
        self.quantity = data["quantity"]
        self.price_one = data["price_one"]
        self.size = data["size"]
        self.bread = data["bread"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]
        self.user = None

    @classmethod
    def save(cls, data):
        query = '''INSERT into sandwiches
        (is_in_cart,quantity,price_one,size,bread,user_id)
        values (1,%(quantity)s,1.00,%(size)s,%(bread)s,%(user_id)s);'''
        return connectToMySQL(cls.DB).query_db(query,data)



    @classmethod
    def delete(cls, sandwich_id):
        query = "DELETE from sandwiches WHERE id = %(id)s;"
        connectToMySQL(cls.DB).query_db(query, {"id": sandwich_id})
        return sandwich_id

    @classmethod
    def remove_from_cart(cls, sandwich_id):
        query = '''UPDATE sandwiches SET is_in_cart = 1 WHERE id = %(id)s;'''
        connectToMySQL(cls.DB).query_db(query, {"id": sandwich_id})
        return sandwich_id

    @classmethod
    def add_to_cart(cls, sandwich_id):
        query = '''UPDATE sandwiches SET is_in_cart = 0 WHERE id = %(id)s;'''
        connectToMySQL(cls.DB).query_db(query, {"id": sandwich_id})
        return sandwich_id

    @classmethod
    def purchase_from_cart(cls):
        query = '''UPDATE sandwiches JOIN users on sandwiches.user_id = users.id
                SET is_in_cart = 1;'''
        connectToMySQL(cls.DB).query_db(query)
        return



    @classmethod
    def get_by_in_cart(cls): # A value of 0 means the sandwich is in the cart.
        query = """SELECT * from sandwiches JOIN users on sandwiches.user_id = users.id
                WHERE is_in_cart = 0"""
        results = connectToMySQL(cls.DB).query_db(query)
        all_sandwiches = []
        for rec_dict in results:
            rec_var = Sandwich(rec_dict)
            user_var = User({
                "id": rec_dict["user_id"],
                "email": rec_dict["email"],
                "first_name": rec_dict["first_name"],
                "last_name": rec_dict["last_name"],
                "created_at": rec_dict["users.created_at"],
                "updated_at": rec_dict["users.updated_at"],
                "password": rec_dict["password"],
                "city": rec_dict["city"],
                "state": rec_dict["state"]
            })
            rec_var.user = user_var
            all_sandwiches.append(rec_var)
        return all_sandwiches

    @classmethod    #still a work in progress, clearly :/
    def get_all(cls):
        query = """SELECT * from sandwiches JOIN users on sandwiches.user_id = users.id;"""
        results = connectToMySQL(cls.DB).query_db(query)
        # print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        # print(connectToMySQL(cls.DB).query_db(query))
        all_sandwiches = []
        for rec_dict in results:
            rec_var = Sandwich(rec_dict)
            user_var = User({
                "id": rec_dict["user_id"],
                "email": rec_dict["email"],
                "first_name": rec_dict["first_name"],
                "last_name": rec_dict["last_name"],
                "created_at": rec_dict["users.created_at"],
                "updated_at": rec_dict["users.updated_at"],
                "password": rec_dict["password"],
                "city": rec_dict["city"],
                "state": rec_dict["state"]
            })
            rec_var.user = user_var
            all_sandwiches.append(rec_var)
        return all_sandwiches

    @classmethod
    def get_one(cls,sandwich_id):
        query = '''SELECT * FROM sandwiches JOIN users ON sandwiches.users_id = users.id WHERE sandwiches.id = %(id)s;'''
        data={
            "id": sandwich_id
        }
        rec_dict = connectToMySQL(cls.DB).query_db(query,data)[0]
        rec_obj = Sandwich(rec_dict)
        user_obj = User({
            "id": rec_dict["users.id"],
            "email": rec_dict["email"],
            "first_name": rec_dict["first_name"],
            "last_name": rec_dict["last_name"],
            "created_at": rec_dict["users.created_at"],
            "updated_at": rec_dict["users.updated_at"],
            "password": rec_dict["password"]
        })
        rec_obj.user = user_obj
        return rec_obj
